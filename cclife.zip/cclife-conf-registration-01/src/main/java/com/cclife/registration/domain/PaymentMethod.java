package com.cclife.registration.domain;

import java.io.Serializable;

public enum PaymentMethod implements Serializable {
    PERSONAL_CHECK, CREDIT_CARD, CASH, WAIVED;
}
