package com.cclife.registration.domain;

import java.io.Serializable;

public enum Seminar implements Serializable {
    A1, A2, B1, B2, C, D, E, F, G1, G2, H, I1, I2, J, K, L, M, N, O, P, Q, R, S, T, U1, U2, V1, V2, W, X, Y, Z;
}
