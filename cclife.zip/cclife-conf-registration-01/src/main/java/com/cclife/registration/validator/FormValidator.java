package com.cclife.registration.validator;

import com.cclife.registration.domain.PaymentMethod;
import com.cclife.registration.domain.RegistrationForm;
import org.apache.log4j.Logger;
import org.springframework.binding.message.MessageBuilder;
import org.springframework.binding.message.MessageContext;
import org.springframework.binding.validation.ValidationContext;
import org.springframework.stereotype.Component;


@Component
public class FormValidator {

    private static final Logger logger = Logger.getLogger(FormValidator.class);

    public void validateReview(RegistrationForm form, ValidationContext context) {

        MessageContext messages = context.getMessageContext();

        if (form.getPaymentMethod() != PaymentMethod.CREDIT_CARD && form.getPaymentMethod() != PaymentMethod.PERSONAL_CHECK) {
            messages.addMessage(new MessageBuilder().error().source("paymentMethod").
                    defaultText("Please select your payment option").build());
        }

        logger.debug("Validate review1 state..[" + form.getPaymentMethod() + "]");

    }
        
    public void validateStep1(RegistrationForm form, ValidationContext context) {
        
        MessageContext messages = context.getMessageContext();

        if (form.getAddress().getHomeAddress().trim().isEmpty() ) {
            messages.addMessage(new MessageBuilder().error().source("homeStreetAddress").
                    defaultText("Please enter your home address. ").build());
        }

        if (form.getAddress().getHomeCity().trim().isEmpty() ) {
            messages.addMessage(new MessageBuilder().error().source("homeCity").
                    defaultText("Please enter your city. ").build());
        }

         if (form.getAddress().getHomeState().trim().isEmpty() ) {
            messages.addMessage(new MessageBuilder().error().source("homeState").
                    defaultText("Please enter your state. ").build());
        }

         if (form.getAddress().getCountry().trim().isEmpty() ) {
            messages.addMessage(new MessageBuilder().error().source("homeCountry").
                    defaultText("Please enter your country. ").build());
        }

         if (form.getAddress().getHomeZip().trim().isEmpty() ) {
            messages.addMessage(new MessageBuilder().error().source("homeZipCode").
                    defaultText("Please enter your zip code. ").build());
        }

      logger.debug("Validate step1 state..[" + form.getPaymentMethod() + "]");

        
    }

}
