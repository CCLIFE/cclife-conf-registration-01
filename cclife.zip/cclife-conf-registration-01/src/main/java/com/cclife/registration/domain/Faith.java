package com.cclife.registration.domain;

import java.io.Serializable;

public enum Faith implements Serializable {
    BELIEVER, SEEKER;
}
