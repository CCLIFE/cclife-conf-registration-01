/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cclife.registration.dao;


import com.cclife.registration.model.Person;

/**
 *
 * @author CHEH
 */
public interface PersonDao extends GenericDao<Person, Long> {


}
